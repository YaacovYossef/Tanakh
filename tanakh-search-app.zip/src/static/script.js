// Global variables
let availableNames = [];
let currentHighlightedIndex = -1;

// DOM elements
const tabButtons = document.querySelectorAll('.tab-button');
const tabContents = document.querySelectorAll('.tab-content');
const nameInput = document.getElementById('name-input');
const nameSuggestions = document.getElementById('name-suggestions');
const searchByNameBtn = document.getElementById('search-by-name-btn');
const searchByLettersBtn = document.getElementById('search-by-letters-btn');
const startLetterInput = document.getElementById('start-letter');
const endLetterInput = document.getElementById('end-letter');
const resultsSection = document.getElementById('results-section');
const nameMatchInfo = document.getElementById('name-match-info');
const versesContainer = document.getElementById('verses-container');
const loadingDiv = document.getElementById('loading');
const errorDiv = document.getElementById('error');
const noResultsDiv = document.getElementById('no-results');
const resultsInfo = document.getElementById('results-info');

// Legacy elements for compatibility
const legacySearchButton = document.getElementById('searchButton');
const legacyStartLetter = document.getElementById('startLetter');
const legacyEndLetter = document.getElementById('endLetter');
const legacyResultsList = document.getElementById('results-list');
const legacyOccurrenceInfo = document.getElementById('occurrence-info');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeTabs();
    initializeAutocomplete();
    initializeEventListeners();
    loadAvailableNames();
    
    // Legacy compatibility
    initializeLegacySearch();
});

// Tab functionality
function initializeTabs() {
    if (tabButtons.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const targetTab = button.getAttribute('data-tab');
                switchTab(targetTab);
            });
        });
    }
}

function switchTab(targetTab) {
    // Update tab buttons
    tabButtons.forEach(btn => btn.classList.remove('active'));
    const targetButton = document.querySelector(`[data-tab="${targetTab}"]`);
    if (targetButton) targetButton.classList.add('active');
    
    // Update tab contents
    tabContents.forEach(content => content.classList.remove('active'));
    const targetContent = document.getElementById(targetTab);
    if (targetContent) targetContent.classList.add('active');
}

// Autocomplete functionality
function initializeAutocomplete() {
    if (nameInput) {
        nameInput.addEventListener('input', handleNameInput);
        nameInput.addEventListener('keydown', handleNameKeydown);
        document.addEventListener('click', handleDocumentClick);
    }
}

function handleNameInput(e) {
    const query = e.target.value.toLowerCase();
    if (query.length < 1) {
        hideSuggestions();
        return;
    }
    
    const filteredNames = availableNames.filter(name => 
        name.toLowerCase().includes(query)
    );
    
    showSuggestions(filteredNames);
}

function handleNameKeydown(e) {
    const suggestions = nameSuggestions.querySelectorAll('.autocomplete-suggestion');
    
    if (e.key === 'ArrowDown') {
        e.preventDefault();
        currentHighlightedIndex = Math.min(currentHighlightedIndex + 1, suggestions.length - 1);
        updateHighlight(suggestions);
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        currentHighlightedIndex = Math.max(currentHighlightedIndex - 1, -1);
        updateHighlight(suggestions);
    } else if (e.key === 'Enter') {
        e.preventDefault();
        if (currentHighlightedIndex >= 0 && suggestions[currentHighlightedIndex]) {
            selectSuggestion(suggestions[currentHighlightedIndex].textContent);
        } else {
            searchByName();
        }
    } else if (e.key === 'Escape') {
        hideSuggestions();
    }
}

function handleDocumentClick(e) {
    if (nameInput && nameSuggestions && 
        !nameInput.contains(e.target) && !nameSuggestions.contains(e.target)) {
        hideSuggestions();
    }
}

function showSuggestions(names) {
    if (!nameSuggestions || names.length === 0) {
        hideSuggestions();
        return;
    }
    
    nameSuggestions.innerHTML = names.map(name => 
        `<div class="autocomplete-suggestion">${name}</div>`
    ).join('');
    
    nameSuggestions.classList.add('show');
    currentHighlightedIndex = -1;
    
    // Add click listeners to suggestions
    nameSuggestions.querySelectorAll('.autocomplete-suggestion').forEach(suggestion => {
        suggestion.addEventListener('click', () => {
            selectSuggestion(suggestion.textContent);
        });
    });
}

function hideSuggestions() {
    if (nameSuggestions) {
        nameSuggestions.classList.remove('show');
    }
    currentHighlightedIndex = -1;
}

function updateHighlight(suggestions) {
    suggestions.forEach((suggestion, index) => {
        suggestion.classList.toggle('highlighted', index === currentHighlightedIndex);
    });
}

function selectSuggestion(name) {
    if (nameInput) {
        nameInput.value = name;
    }
    hideSuggestions();
    searchByName();
}

// Event listeners
function initializeEventListeners() {
    if (searchByNameBtn) {
        searchByNameBtn.addEventListener('click', searchByName);
    }
    
    if (searchByLettersBtn) {
        searchByLettersBtn.addEventListener('click', searchByLetters);
    }
    
    // Enter key support
    if (nameInput) {
        nameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && currentHighlightedIndex === -1) {
                searchByName();
            }
        });
    }
    
    if (startLetterInput) {
        startLetterInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') searchByLetters();
        });
    }
    
    if (endLetterInput) {
        endLetterInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') searchByLetters();
        });
    }
}

// Legacy search initialization
function initializeLegacySearch() {
    if (legacySearchButton && legacyStartLetter && legacyEndLetter) {
        legacySearchButton.addEventListener("click", async function() {
            const startLetter = legacyStartLetter.value.trim();
            const endLetter = legacyEndLetter.value.trim();

            if (!startLetter || !endLetter) {
                alert("Veuillez entrer une première et une dernière lettre.");
                return;
            }

            if (legacyResultsList) legacyResultsList.innerHTML = "";
            if (legacyOccurrenceInfo) legacyOccurrenceInfo.textContent = "";

            try {
                const response = await fetch("/api/tanakh/search", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ start_letter: startLetter, end_letter: endLetter })
                });

                const data = await response.json();

                if (data.error) {
                    if (legacyResultsList) {
                        legacyResultsList.innerHTML = `<li>Erreur: ${data.error}</li>`;
                    }
                    return;
                }

                if (legacyOccurrenceInfo) {
                    legacyOccurrenceInfo.textContent = `Nombre d'occurrences pour la paire (${startLetter}, ${endLetter}): ${data.occurrence_count}`;
                }

                if (data.results.length === 0) {
                    if (legacyResultsList) {
                        legacyResultsList.innerHTML = "<li>Aucun verset trouvé pour cette paire de lettres.</li>";
                    }
                } else {
                    data.results.forEach(verse => {
                        const listItem = document.createElement("li");
                        listItem.innerHTML = `
                            <div class="verse-reference">${verse.reference}</div>
                            <div class="verse-text">${verse.text}</div>
                            ${verse.translation_fr ? `<div class="translation-text">Traduction FR: ${verse.translation_fr}</div>` : ''}
                            ${verse.rashi_commentary ? `<div class="rashi-commentary">Rashi: ${verse.rashi_commentary}</div>` : ''}
                        `;
                        if (legacyResultsList) {
                            legacyResultsList.appendChild(listItem);
                        }
                    });
                }

            } catch (error) {
                if (legacyResultsList) {
                    legacyResultsList.innerHTML = `<li>Une erreur est survenue lors de la recherche: ${error.message}</li>`;
                }
                console.error("Erreur lors de la recherche:", error);
            }
        });
    }
}

// Load available names
async function loadAvailableNames() {
    try {
        const response = await fetch('/api/tanakh/names');
        const data = await response.json();
        availableNames = data.names || [];
    } catch (error) {
        console.error('Error loading names:', error);
    }
}

// Search functions
async function searchByName() {
    if (!nameInput) return;
    
    const name = nameInput.value.trim();
    if (!name) {
        showError('Veuillez entrer un prénom.');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch('/api/tanakh/search_by_name', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name: name })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Erreur lors de la recherche');
        }
        
        displayResults(data);
    } catch (error) {
        showError(error.message);
    } finally {
        hideLoading();
    }
}

async function searchByLetters() {
    if (!startLetterInput || !endLetterInput) return;
    
    const startLetter = startLetterInput.value.trim();
    const endLetter = endLetterInput.value.trim();
    
    if (!startLetter || !endLetter) {
        showError('Veuillez entrer les deux lettres.');
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch('/api/tanakh/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                start_letter: startLetter, 
                end_letter: endLetter 
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Erreur lors de la recherche');
        }
        
        displayResults(data);
    } catch (error) {
        showError(error.message);
    } finally {
        hideLoading();
    }
}

// Display functions
function displayResults(data) {
    clearResults();
    showResultsSection();
    
    if (data.name_match) {
        displayNameMatchInfo(data.name_match);
    }
    
    if (data.results && data.results.length > 0) {
        displayVerses(data.results);
        updateResultsInfo(data);
    } else {
        showNoResults();
    }
}

function displayNameMatchInfo(nameMatch) {
    if (nameMatchInfo) {
        const hebrewNameDisplay = document.getElementById('hebrew-name-display');
        const letterPairDisplay = document.getElementById('letter-pair-display');
        const occurrencesDisplay = document.getElementById('occurrences-display');
        
        if (hebrewNameDisplay) hebrewNameDisplay.textContent = nameMatch.hebrew_name;
        if (letterPairDisplay) letterPairDisplay.textContent = nameMatch.letter_pair;
        if (occurrencesDisplay) occurrencesDisplay.textContent = nameMatch.occurrences;
        
        nameMatchInfo.style.display = 'block';
    }
}

function displayVerses(verses) {
    if (versesContainer) {
        versesContainer.innerHTML = verses.map(verse => `
            <div class="verse-card">
                <div class="verse-reference">${verse.reference}</div>
                <div class="verse-hebrew hebrew-text">${highlightLetters(verse.text, verse.first_char, verse.last_char)}</div>
                ${verse.translation_fr ? `<div class="verse-french">${verse.translation_fr}</div>` : ''}
                ${verse.rashi_commentary ? `<div class="verse-commentary"><strong>Commentaire de Rashi :</strong> ${verse.rashi_commentary}</div>` : ''}
            </div>
        `).join('');
    }
}

function updateResultsInfo(data) {
    if (resultsInfo) {
        const count = data.results.length;
        const occurrenceCount = data.occurrence_count || (data.name_match ? data.name_match.occurrences : 0);
        resultsInfo.textContent = `${count} versets trouvés (${occurrenceCount} occurrences de cette paire de lettres)`;
    }
}

function highlightLetters(text, firstChar, lastChar) {
    if (!text || !firstChar || !lastChar) return text;
    
    let highlightedText = text;
    
    // Highlight first character
    if (text.startsWith(firstChar)) {
        highlightedText = `<span class="highlight-first">${firstChar}</span>${text.slice(1)}`;
    }
    
    // Highlight last character
    if (text.endsWith(lastChar)) {
        const lastIndex = highlightedText.lastIndexOf(lastChar);
        if (lastIndex !== -1) {
            highlightedText = highlightedText.slice(0, lastIndex) + 
                            `<span class="highlight-last">${lastChar}</span>` + 
                            highlightedText.slice(lastIndex + 1);
        }
    }
    
    return highlightedText;
}

// UI state functions
function showLoading() {
    if (loadingDiv) loadingDiv.style.display = 'block';
    hideError();
    hideNoResults();
}

function hideLoading() {
    if (loadingDiv) loadingDiv.style.display = 'none';
}

function showError(message) {
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
    }
    hideLoading();
    hideNoResults();
}

function hideError() {
    if (errorDiv) errorDiv.style.display = 'none';
}

function showNoResults() {
    if (noResultsDiv) noResultsDiv.style.display = 'block';
    hideLoading();
    hideError();
}

function hideNoResults() {
    if (noResultsDiv) noResultsDiv.style.display = 'none';
}

function showResultsSection() {
    if (resultsSection) resultsSection.classList.add('show');
}

function clearResults() {
    if (versesContainer) versesContainer.innerHTML = '';
    if (nameMatchInfo) nameMatchInfo.style.display = 'none';
    hideError();
    hideNoResults();
    hideLoading();
}

