/**
 * Clavier hébreu virtuel dans l'ordre alphabétique
 * Permet aux utilisateurs sans clavier hébreu d'entrer des lettres hébraïques
 */

class HebrewKeyboard {
    constructor() {
        this.isVisible = false;
        this.currentInput = null;
        this.hebrewLetters = [
            { letter: 'א', name: 'Aleph' },
            { letter: 'ב', name: 'Bet' },
            { letter: 'ג', name: 'Gimel' },
            { letter: 'ד', name: 'Dalet' },
            { letter: 'ה', name: 'He' },
            { letter: 'ו', name: 'Vav' },
            { letter: 'ז', name: 'Zayin' },
            { letter: 'ח', name: 'Het' },
            { letter: 'ט', name: 'Tet' },
            { letter: 'י', name: 'Yod' },
            { letter: 'כ', name: 'Kaf' },
            { letter: 'ל', name: 'Lamed' },
            { letter: 'מ', name: 'Mem' },
            { letter: 'נ', name: 'Nun' },
            { letter: 'ס', name: 'Samekh' },
            { letter: 'ע', name: 'Ayin' },
            { letter: 'פ', name: 'Pe' },
            { letter: 'צ', name: 'Tsadi' },
            { letter: 'ק', name: 'Qof' },
            { letter: 'ר', name: 'Resh' },
            { letter: 'ש', name: 'Shin' },
            { letter: 'ת', name: 'Tav' }
        ];
        
        this.init();
    }
    
    init() {
        this.createKeyboard();
        this.attachEventListeners();
    }
    
    createKeyboard() {
        // Créer le conteneur du clavier
        const keyboardContainer = document.createElement('div');
        keyboardContainer.id = 'hebrew-keyboard';
        keyboardContainer.className = 'hebrew-keyboard';
        keyboardContainer.innerHTML = `
            <div class="keyboard-header">
                <h3>Clavier Hébreu</h3>
                <button class="keyboard-close" id="keyboard-close">×</button>
            </div>
            <div class="keyboard-grid" id="keyboard-grid">
                ${this.hebrewLetters.map(letter => `
                    <button class="hebrew-key" data-letter="${letter.letter}" title="${letter.name}">
                        ${letter.letter}
                    </button>
                `).join('')}
            </div>
            <div class="keyboard-actions">
                <button class="keyboard-action" id="keyboard-clear">Effacer</button>
                <button class="keyboard-action" id="keyboard-space">Espace</button>
            </div>
        `;
        
        document.body.appendChild(keyboardContainer);
    }
    
    attachEventListeners() {
        // Bouton de fermeture
        document.getElementById('keyboard-close').addEventListener('click', () => {
            this.hide();
        });
        
        // Boutons des lettres hébraïques
        document.querySelectorAll('.hebrew-key').forEach(key => {
            key.addEventListener('click', (e) => {
                const letter = e.target.getAttribute('data-letter');
                this.insertLetter(letter);
            });
        });
        
        // Actions du clavier
        document.getElementById('keyboard-clear').addEventListener('click', () => {
            if (this.currentInput) {
                this.currentInput.value = '';
                this.currentInput.dispatchEvent(new Event('input'));
            }
        });
        
        document.getElementById('keyboard-space').addEventListener('click', () => {
            this.insertLetter(' ');
        });
        
        // Fermer le clavier en cliquant à l'extérieur
        document.addEventListener('click', (e) => {
            if (this.isVisible && !e.target.closest('.hebrew-keyboard') && !e.target.closest('.keyboard-toggle')) {
                this.hide();
            }
        });
        
        // Échapper pour fermer
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isVisible) {
                this.hide();
            }
        });
    }
    
    show(inputElement) {
        this.currentInput = inputElement;
        this.isVisible = true;
        
        const keyboard = document.getElementById('hebrew-keyboard');
        keyboard.classList.add('show');
        
        // Positionner le clavier près de l'input
        this.positionKeyboard(inputElement);
    }
    
    hide() {
        this.isVisible = false;
        this.currentInput = null;
        
        const keyboard = document.getElementById('hebrew-keyboard');
        keyboard.classList.remove('show');
    }
    
    toggle(inputElement) {
        if (this.isVisible && this.currentInput === inputElement) {
            this.hide();
        } else {
            this.show(inputElement);
        }
    }
    
    positionKeyboard(inputElement) {
        const keyboard = document.getElementById('hebrew-keyboard');
        const inputRect = inputElement.getBoundingClientRect();
        const keyboardRect = keyboard.getBoundingClientRect();
        
        let top = inputRect.bottom + window.scrollY + 10;
        let left = inputRect.left + window.scrollX;
        
        // Ajuster si le clavier dépasse de l'écran
        if (left + keyboardRect.width > window.innerWidth) {
            left = window.innerWidth - keyboardRect.width - 20;
        }
        
        if (top + keyboardRect.height > window.innerHeight + window.scrollY) {
            top = inputRect.top + window.scrollY - keyboardRect.height - 10;
        }
        
        keyboard.style.top = `${top}px`;
        keyboard.style.left = `${left}px`;
    }
    
    insertLetter(letter) {
        if (!this.currentInput) return;
        
        const start = this.currentInput.selectionStart;
        const end = this.currentInput.selectionEnd;
        const value = this.currentInput.value;
        
        // Insérer la lettre à la position du curseur
        const newValue = value.substring(0, start) + letter + value.substring(end);
        this.currentInput.value = newValue;
        
        // Repositionner le curseur
        const newPosition = start + letter.length;
        this.currentInput.setSelectionRange(newPosition, newPosition);
        
        // Déclencher l'événement input pour les écouteurs
        this.currentInput.dispatchEvent(new Event('input'));
        this.currentInput.focus();
    }
}

// Initialiser le clavier hébreu
let hebrewKeyboard;

document.addEventListener('DOMContentLoaded', function() {
    hebrewKeyboard = new HebrewKeyboard();
    
    // Ajouter des boutons de clavier aux inputs hébreux
    addKeyboardButtons();
});

function addKeyboardButtons() {
    // Ajouter des boutons de clavier aux inputs de lettres hébraïques
    const hebrewInputs = document.querySelectorAll('.hebrew-input, #start-letter, #end-letter');
    
    hebrewInputs.forEach(input => {
        // Créer un conteneur pour l'input et le bouton
        const container = document.createElement('div');
        container.className = 'hebrew-input-container';
        
        // Insérer le conteneur avant l'input
        input.parentNode.insertBefore(container, input);
        
        // Déplacer l'input dans le conteneur
        container.appendChild(input);
        
        // Créer le bouton de clavier
        const keyboardButton = document.createElement('button');
        keyboardButton.type = 'button';
        keyboardButton.className = 'keyboard-toggle';
        keyboardButton.innerHTML = '⌨️';
        keyboardButton.title = 'Ouvrir le clavier hébreu';
        
        // Ajouter l'événement de clic sur le bouton
        keyboardButton.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            hebrewKeyboard.toggle(input);
        });
        
        // Ajouter l'événement de focus sur l'input pour lancement automatique
        input.addEventListener('focus', (e) => {
            hebrewKeyboard.show(input);
        });
        
        // Ajouter l'événement de clic sur l'input pour lancement automatique
        input.addEventListener('click', (e) => {
            if (!hebrewKeyboard.isVisible || hebrewKeyboard.currentInput !== input) {
                hebrewKeyboard.show(input);
            }
        });
        
        // Ajouter le bouton au conteneur
        container.appendChild(keyboardButton);
    });
}

